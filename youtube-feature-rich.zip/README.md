# youtube-feature-rich

youtube 配信の chrome 拡張機能 ver3.1.1<br>
[詳しくはこちら](https://blog.yuki0311.com/youtube-feature-rich-v1/ "詳しくはこちら")

# Installation

このサイトの*Clone or download*から*Download ZIP*を選択してファイルをダウンロードして展開
chrome の設定から拡張機能を選択して*デベロッパーモード*をオンにしたあと*パッケージ化されていない拡張機能を読み込む*を選択し  
展開したフォルダを選択してください

# License

youtube-feature-rich is under MIT License
